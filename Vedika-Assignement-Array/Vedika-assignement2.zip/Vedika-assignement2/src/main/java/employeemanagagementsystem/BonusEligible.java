package employeemanagagementsystem;

public interface BonusEligible {
    double calcBonus();
}
